
# ShopEasy Website

This is a simple e-commerce website built with HTML and CSS.

## Files
- index.html: Home Page
- products.html: Product Listing
- about.html: About Us Page
- contact.html: Contact Form
- cart.html: Shopping Cart

## Deployment
Upload the files to any static web hosting platform like Netlify or GitHub Pages.
